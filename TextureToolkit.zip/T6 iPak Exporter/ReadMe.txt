===== Tom Crowley Bo 2 iPak Exporter =====

Site: www.tom-bmx.com
version: 1.22


If you wish to redistribute this program do so by linking to the original download link.
Do not rehost the application.


Note: Setting the export folder to one that is on a diffrent HDD to the ipak will 
help improve export speed, since this program is mainly IO bound.



Options:
	(man)	-f	The iPack file to export
	(opt)		-o	OutputDir (Directory will be created if not present)
	(opt)		-n	Exports Normal Maps
	(opt)		-u	If .dds / .tga exist in Output folder it's updated
	(opt)		-a	Disables the AI file update override
	(opt)		-p	Prefix files with Format Name
	(opt)		-d	Logs and displays texture dimensions
	(opt)		-nf	Disable Normal vertical flipping
	(opt)		-ra	Disable Intelligent DXT5 Alpha removal, Decides if alpha
				should be removed.
	
	(opt)		-l	Disable the IWI Name Linker System


You can also drop a iPak directly onto the exe to load it. 

Note: Do not drag the file on to the programs console window this will do nothing, you must actually drop it on the exe file.


Normal Maps:

Normal maps are not exported by default since not everyone wants them, plus the program decompresses 
them on the fly to 32-but TGA meaning some normal maps will be 16mb in size. Leading to a large
amount of HDD space been used for normal maps.

If you wish to export normal maps use the -n flag



Flag -u

This flag turns off the programs file checking system to see if the file already exsists before exporting.
Use this flag if you have editing a texture and want to update it with the original.

Leaving this off is useful though since if you have exported the iPak to the same directory previously
And just want to get retrive files you have deleted the export will complete much quicker.

Flag -a

Disables the programs AI that will decided if file exsists checks should be turned off to help increased export
speed.

Flag -p

File names are prefixed with the internal formats name.

For example: 	DXT5_636064646.dds
			DXT1_24256363.dds
			
Flag -d 

Turns on the image dimension logging system which displays a report after export showing what size textures
this iPak contains.


Flag -l

The linker system is responsible for linking iwi FileId's to text based names.
Setting this flag will disable the search resulting in all files using the FileID as a name.

Flag -nf

The normal maps in BO 2 are by default vertically flipped in comparision to the Color maps.
The program will automatically flip the image unless this flag is set.

Flag -ra

In BO 2 alot ofthe color maps are DXT5 alpha and don't have solid alpha channels, I suspect this alpha
data is used in some way by the shaders.

If you want to use the color map in older versions of COD the engine will not handle the color maps correct.
By default the program works out if the alpha channels should be removed.

By setting this flag alpha channel removal is disabled. But from my testing it works very well.
